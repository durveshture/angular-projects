import { Component, OnInit } from '@angular/core';
import { StudentModel } from '../model/student';
import { Router } from '@angular/router';
import { StudentService } from '../service/student.service';

@Component({
  selector: 'app-try',
  templateUrl: './try.component.html',
  styleUrls: ['./try.component.css']
})
export class TryComponent implements OnInit {
  studentArr: StudentModel[];
  confirmationStatus;

  constructor(private studentService: StudentService,private router: Router) { 
    this.studentArr = [];
  }

  ngOnInit() {
    this.studentArr = this.studentService.getStudents();
  }
  delete(index: number) {
    // ask user confirmation on delete
    this.confirmationStatus = confirm('Do you want to delete the task?');
    if (this.confirmationStatus) {
      this.studentService.delete(index);
    }
  }
  oneditClick() {
    this.router.navigate(['/updatetask']);
  }

}
