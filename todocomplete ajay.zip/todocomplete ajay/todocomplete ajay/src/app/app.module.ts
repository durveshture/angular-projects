import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { TryComponent } from './try/try.component';
import { LoginComponent } from './login/login.component';
import { StudentService } from './service/student.service';
import { CreateComponent } from './create/create.component';
import { UpdatetaskComponent } from './updatetask/updatetask.component';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component:HomeComponent , pathMatch: 'full' },
  { path: 'try', component:TryComponent , pathMatch: 'full' },
  { path: 'login', component:LoginComponent , pathMatch: 'full' },
  { path: 'create', component:CreateComponent , pathMatch: 'full' },
  { path: 'updatetask', component:UpdatetaskComponent , pathMatch: 'full' },
  { path: '**', redirectTo: 'home', pathMatch: 'full' },

];

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    TryComponent,
    LoginComponent,
    CreateComponent,
    UpdatetaskComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    FormsModule
  ],
  providers: [StudentService],   
  bootstrap: [AppComponent]
})
export class AppModule { }
