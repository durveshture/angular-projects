import { Component, OnInit } from '@angular/core';
import { StudentService } from '../service/student.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  emailaddress:string=""
  password:string=""


  constructor(private studentService:StudentService, private routes: Router) { 
    
  }
  
  public onLoginClick(){
    this.studentService.checkUser(this.emailaddress,this.password);
    
 }
  ngOnInit() {
  }

}
