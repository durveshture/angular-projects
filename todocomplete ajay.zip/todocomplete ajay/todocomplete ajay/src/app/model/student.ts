export class StudentModel {  //to create an class of user

    public studentEmail: String;
    public studentPassword: String;
    public studentName: String;
    public studentSubject: String;
    public studentHobbies: String;
    public studentId: number;

}