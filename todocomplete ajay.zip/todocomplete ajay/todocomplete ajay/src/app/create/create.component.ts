import { Component, OnInit, Input } from '@angular/core';
import { StudentModel } from '../model/student';
import { Router } from '@angular/router';
import { StudentService } from '../service/student.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
//to create new user or edit it
@Input() student: StudentModel;
  constructor(private routes: Router, private studentService: StudentService) { 

    this.student = new StudentModel;
  }
  public onSubmitClick() {
    this.studentService.add(this.student);
    this.student = new StudentModel();
    this.routes.navigate(['/try']);
  }


  ngOnInit() {
  }

}
