import { Injectable } from '@angular/core';
import { StudentModel } from '../model/student';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  studentArr: StudentModel[];



  constructor(private routes: Router) {
    this.studentArr = [];
  }

  add(user: StudentModel) {
    // add task to array
    this.studentArr.push(user);
    this.routes.navigate(['/todoo']);
  }
  getStudents() {
    console.log(this.studentArr);
    return this.studentArr;
  }
  checkUser(username: string, password: string) {
    if (username == "admin@gmail.com" && password == "12345") {
      this.routes.navigate(['/create']);
    }

  }
  delete(i: number) {
    this.studentArr.splice(i, 1);
  }
  editTask(index: number) {
    // add id of task through route to prefill and edit particular task
    this.routes.navigate(['/updatetask'], { queryParams: { id: index } });
  }
  getDetailsOf(index) {
    // get details of particular task
    return this.studentArr[index];
  }
  edit(index: number, updatedTask: StudentModel) {
    // update edited task details to array
    this.studentArr[index] = updatedTask;
    this.routes.navigate(['/try']);
  }

}