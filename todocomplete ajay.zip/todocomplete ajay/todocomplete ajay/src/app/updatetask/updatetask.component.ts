import { Component, OnInit } from '@angular/core';
import { StudentModel } from '../model/student';
import { Router, ActivatedRoute } from '@angular/router';
import { StudentService } from '../service/student.service';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-updatetask',
  templateUrl: './updatetask.component.html',
  styleUrls: ['./updatetask.component.css']
})
export class UpdatetaskComponent implements OnInit {
  updatedTask: StudentModel;
  paramIndex = 0;

  constructor(private route: ActivatedRoute, private router: Router, private studentService: StudentService) { 
  this.updatedTask = new StudentModel();
}

ngOnInit() {
  if (window.location.search !== '') {
    // take id from route query param and prefill data of particular task
    this.route.queryParams.pipe(
      filter(params => params.id))
      .subscribe(params => {
        console.log(params.id);
        this.paramIndex = params.id;
        this.updatedTask = this.studentService.getDetailsOf(this.paramIndex);
        console.log(this.updatedTask)
      });
  }
}
updateTask() {
  // send index of task and updated details
  this.studentService.edit(this.paramIndex, this.updatedTask);
}
}
