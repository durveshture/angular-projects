import { ToDoTasks } from './../Models/ToDoTasks';
import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { LoginModel } from "../Models/LoginModel";


@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"]
})
export class LoginComponent implements OnInit {
  login: LoginModel;


  constructor(private routes: Router) {
    this.login= new LoginModel();
    // this.login.userEmail = "admin@gmail.com";
    // this.login.password = "123456";
  }
  ngOnInit() {

  }

  goToHome() {
    this.routes.navigate(["/home"]);
  }

  checkLogin() {
    // console.log(this.login.userEmail);
    // console.log(this.login.password);
    if (this.login.userEmail=="admin@gmail.com" && this.login.password=="123456") {
      this.login= new LoginModel();
      this.routes.navigate(['/todo']);
    } else {
      this.routes.navigate(['/login']);
    }
  }


}
