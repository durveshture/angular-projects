import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { ToDoTasks } from '../Models/ToDoTasks';
import { TaskServiceService } from '../Services/task-service.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  taskArray: ToDoTasks[];
  tasks: ToDoTasks;

  constructor(private service:TaskServiceService,private routes:Router) {
    this.tasks= new ToDoTasks();
   }

  ngOnInit() {
    this.tasks= new ToDoTasks();
    this.tasks.taskStatus = "incomplete";
  }

  saveTask(){
   this.service.saveTask(this.tasks);
  }

  goBack(){
    this.routes.navigate(['/todo']);
  }


}
