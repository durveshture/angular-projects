import { Component, OnInit } from '@angular/core';
import { ToDoTasks } from '../Models/ToDoTasks';

import { Router } from '@angular/router';
import { TaskServiceService } from '../Services/task-service.service';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {

  taskArray: ToDoTasks[];
  // tasks: ToDoTasks;
  taskToEdit: ToDoTasks;

  constructor(private service:TaskServiceService,private routes:Router) { }

  ngOnInit() {
  this.taskArray= this.service.getTasks();
  }

  addNewTask(){
  //  this.service.saveTask();
  this.routes.navigate(['/create']);
  }

  editTask(id:number){
   this.taskToEdit=this.service.updateTask(id);
  }

  deleteTask(id:number){
   this.service.deleteTask(id);
  }


}
